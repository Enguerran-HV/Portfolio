/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.0.0
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set IO_RA4 aliases
#define LED_STOP_TRIS                 TRISAbits.TRISA4
#define LED_STOP_LAT                  LATAbits.LATA4
#define LED_STOP_PORT                 PORTAbits.RA4
#define LED_STOP_WPU                  WPUAbits.WPUA4
#define LED_STOP_OD                   ODCONAbits.ODCA4
#define LED_STOP_ANS                  ANSELAbits.ANSA4
#define LED_STOP_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define LED_STOP_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define LED_STOP_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define LED_STOP_GetValue()           PORTAbits.RA4
#define LED_STOP_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define LED_STOP_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define LED_STOP_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define LED_STOP_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define LED_STOP_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define LED_STOP_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define LED_STOP_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define LED_STOP_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)
// get/set IO_RB0 aliases
#define PWM_D1_TRIS                 TRISBbits.TRISB0
#define PWM_D1_LAT                  LATBbits.LATB0
#define PWM_D1_PORT                 PORTBbits.RB0
#define PWM_D1_WPU                  WPUBbits.WPUB0
#define PWM_D1_OD                   ODCONBbits.ODCB0
#define PWM_D1_ANS                  ANSELBbits.ANSB0
#define PWM_D1_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define PWM_D1_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define PWM_D1_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define PWM_D1_GetValue()           PORTBbits.RB0
#define PWM_D1_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define PWM_D1_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define PWM_D1_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define PWM_D1_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define PWM_D1_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define PWM_D1_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define PWM_D1_SetAnalogMode()      do { ANSELBbits.ANSB0 = 1; } while(0)
#define PWM_D1_SetDigitalMode()     do { ANSELBbits.ANSB0 = 0; } while(0)
// get/set IO_RB1 aliases
#define PWM_D2_TRIS                 TRISBbits.TRISB1
#define PWM_D2_LAT                  LATBbits.LATB1
#define PWM_D2_PORT                 PORTBbits.RB1
#define PWM_D2_WPU                  WPUBbits.WPUB1
#define PWM_D2_OD                   ODCONBbits.ODCB1
#define PWM_D2_ANS                  ANSELBbits.ANSB1
#define PWM_D2_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define PWM_D2_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define PWM_D2_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define PWM_D2_GetValue()           PORTBbits.RB1
#define PWM_D2_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define PWM_D2_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define PWM_D2_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define PWM_D2_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define PWM_D2_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define PWM_D2_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define PWM_D2_SetAnalogMode()      do { ANSELBbits.ANSB1 = 1; } while(0)
#define PWM_D2_SetDigitalMode()     do { ANSELBbits.ANSB1 = 0; } while(0)
// get/set IO_RB2 aliases
#define PWM_G1_TRIS                 TRISBbits.TRISB2
#define PWM_G1_LAT                  LATBbits.LATB2
#define PWM_G1_PORT                 PORTBbits.RB2
#define PWM_G1_WPU                  WPUBbits.WPUB2
#define PWM_G1_OD                   ODCONBbits.ODCB2
#define PWM_G1_ANS                  ANSELBbits.ANSB2
#define PWM_G1_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define PWM_G1_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define PWM_G1_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define PWM_G1_GetValue()           PORTBbits.RB2
#define PWM_G1_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define PWM_G1_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define PWM_G1_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define PWM_G1_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define PWM_G1_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define PWM_G1_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define PWM_G1_SetAnalogMode()      do { ANSELBbits.ANSB2 = 1; } while(0)
#define PWM_G1_SetDigitalMode()     do { ANSELBbits.ANSB2 = 0; } while(0)
// get/set IO_RB3 aliases
#define PWM_G2_TRIS                 TRISBbits.TRISB3
#define PWM_G2_LAT                  LATBbits.LATB3
#define PWM_G2_PORT                 PORTBbits.RB3
#define PWM_G2_WPU                  WPUBbits.WPUB3
#define PWM_G2_OD                   ODCONBbits.ODCB3
#define PWM_G2_ANS                  ANSELBbits.ANSB3
#define PWM_G2_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define PWM_G2_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define PWM_G2_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define PWM_G2_GetValue()           PORTBbits.RB3
#define PWM_G2_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define PWM_G2_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define PWM_G2_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define PWM_G2_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define PWM_G2_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define PWM_G2_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define PWM_G2_SetAnalogMode()      do { ANSELBbits.ANSB3 = 1; } while(0)
#define PWM_G2_SetDigitalMode()     do { ANSELBbits.ANSB3 = 0; } while(0)
// get/set IO_RB4 aliases
#define LED_GAUCHE_TRIS                 TRISBbits.TRISB4
#define LED_GAUCHE_LAT                  LATBbits.LATB4
#define LED_GAUCHE_PORT                 PORTBbits.RB4
#define LED_GAUCHE_WPU                  WPUBbits.WPUB4
#define LED_GAUCHE_OD                   ODCONBbits.ODCB4
#define LED_GAUCHE_ANS                  ANSELBbits.ANSB4
#define LED_GAUCHE_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define LED_GAUCHE_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define LED_GAUCHE_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define LED_GAUCHE_GetValue()           PORTBbits.RB4
#define LED_GAUCHE_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define LED_GAUCHE_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define LED_GAUCHE_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define LED_GAUCHE_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define LED_GAUCHE_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define LED_GAUCHE_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define LED_GAUCHE_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define LED_GAUCHE_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)
// get/set IO_RC0 aliases
#define POT_TRIS                 TRISCbits.TRISC0
#define POT_LAT                  LATCbits.LATC0
#define POT_PORT                 PORTCbits.RC0
#define POT_WPU                  WPUCbits.WPUC0
#define POT_OD                   ODCONCbits.ODCC0
#define POT_ANS                  ANSELCbits.ANSC0
#define POT_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define POT_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define POT_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define POT_GetValue()           PORTCbits.RC0
#define POT_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define POT_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define POT_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define POT_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define POT_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define POT_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define POT_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define POT_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)
// get/set IO_RC4 aliases
#define Tx_TRIS                 TRISCbits.TRISC4
#define Tx_LAT                  LATCbits.LATC4
#define Tx_PORT                 PORTCbits.RC4
#define Tx_WPU                  WPUCbits.WPUC4
#define Tx_OD                   ODCONCbits.ODCC4
#define Tx_ANS                  ANSELCbits.ANSC4
#define Tx_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define Tx_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define Tx_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define Tx_GetValue()           PORTCbits.RC4
#define Tx_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define Tx_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define Tx_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define Tx_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define Tx_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define Tx_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define Tx_SetAnalogMode()      do { ANSELCbits.ANSC4 = 1; } while(0)
#define Tx_SetDigitalMode()     do { ANSELCbits.ANSC4 = 0; } while(0)
// get/set IO_RC5 aliases
#define Rx_TRIS                 TRISCbits.TRISC5
#define Rx_LAT                  LATCbits.LATC5
#define Rx_PORT                 PORTCbits.RC5
#define Rx_WPU                  WPUCbits.WPUC5
#define Rx_OD                   ODCONCbits.ODCC5
#define Rx_ANS                  ANSELCbits.ANSC5
#define Rx_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define Rx_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define Rx_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define Rx_GetValue()           PORTCbits.RC5
#define Rx_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define Rx_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define Rx_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define Rx_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define Rx_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define Rx_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define Rx_SetAnalogMode()      do { ANSELCbits.ANSC5 = 1; } while(0)
#define Rx_SetDigitalMode()     do { ANSELCbits.ANSC5 = 0; } while(0)
// get/set IO_RC6 aliases
#define LED_DROITE_TRIS                 TRISCbits.TRISC6
#define LED_DROITE_LAT                  LATCbits.LATC6
#define LED_DROITE_PORT                 PORTCbits.RC6
#define LED_DROITE_WPU                  WPUCbits.WPUC6
#define LED_DROITE_OD                   ODCONCbits.ODCC6
#define LED_DROITE_ANS                  ANSELCbits.ANSC6
#define LED_DROITE_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define LED_DROITE_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define LED_DROITE_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define LED_DROITE_GetValue()           PORTCbits.RC6
#define LED_DROITE_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define LED_DROITE_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define LED_DROITE_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define LED_DROITE_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define LED_DROITE_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define LED_DROITE_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define LED_DROITE_SetAnalogMode()      do { ANSELCbits.ANSC6 = 1; } while(0)
#define LED_DROITE_SetDigitalMode()     do { ANSELCbits.ANSC6 = 0; } while(0)
/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/
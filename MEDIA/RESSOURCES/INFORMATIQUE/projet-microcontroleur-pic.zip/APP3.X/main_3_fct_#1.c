
#include "mcc_generated_files/system/system.h"

int Reculer(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(vts);
    PWM_G1_LoadDutyValue(vts);
    PWM_G2_LoadDutyValue(0);   
return 0;
}

int Avancer(int vts)
{
    PWM_D1_LoadDutyValue(vts);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(vts);   
return 0;
}

int Stopper(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(0); 
}

int Gauche(int vts)
{
    PWM_D1_LoadDutyValue(vts);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(vts);
    PWM_G2_LoadDutyValue(0); 
}

int Droite(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(vts);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(vts); 
}




int main(void)
{
    SYSTEM_Initialize(); 
    
    uint16_t val_pot;
    float pourcent;
    
    while(1)
    { 
        val_pot = ADC_ChannelSelectAndConvert(POT);
        
        Avancer(val_pot);
        printf("\navancer");
        
        __delay_ms(500);
        
        Stopper(val_pot);
        printf("\nstopper");
        __delay_ms(500);
        
        Reculer(val_pot);
        printf("\nreculer");
        
        __delay_ms(500);
        
        Stopper(val_pot);
        printf("\nstopper");
        __delay_ms(500);
        
        Gauche(val_pot);
        printf("\ngauche");
        __delay_ms(500);
        
        Stopper(val_pot);
        printf("\nstopper");
        __delay_ms(500);
        
        Droite(val_pot);
        printf("\ndroite");
        __delay_ms(500);
        
        Stopper(val_pot);
        printf("\nstopper");
        __delay_ms(500);
        
    }
}
 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize(); 


    while(1)
    { /* Avant  */
        LED_GAUCHE_SetHigh();
        LED_DROITE_SetLow();
        LED_STOP_SetLow();
        
        Ain1_SetHigh();
        Ain2_SetLow();
        Bin1_SetLow();
        Bin2_SetHigh();
        
        printf("Marche Avant");
        printf("\n");
        
        __delay_ms(500);
        
        /* Arret  */
        LED_GAUCHE_SetLow();
        LED_DROITE_SetLow();
        LED_STOP_SetHigh();
        
        Ain1_SetLow();
        Ain2_SetLow();
        Bin1_SetLow();
        Bin2_SetLow();
       
        printf("Arret");
        printf("\n");
        
        __delay_ms(500);
        
        
        /* Arri�re  */
        LED_DROITE_SetHigh();
        LED_GAUCHE_SetLow();
        LED_STOP_SetLow();
        
        Ain1_SetLow();
        Ain2_SetHigh();
        Bin1_SetHigh();
        Bin2_SetLow();
        
        printf("Marche Arri�re");
        printf("\n");
        
        __delay_ms(500);
        
        /* Arret  */
        LED_GAUCHE_SetLow();
        LED_DROITE_SetLow();
        LED_STOP_SetHigh();
        
        Ain1_SetLow();
        Ain2_SetLow();
        Bin1_SetLow();
        Bin2_SetLow();
        
        printf("Arret");
        printf("\n");
        
        __delay_ms(500);
        
    }    
}

#include "mcc_generated_files/system/system.h"

int Reculer(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(vts);
    PWM_G1_LoadDutyValue(vts);
    PWM_G2_LoadDutyValue(0);   
    LED_STOP_SetLow();
    LED_GAUCHE_SetLow();
    LED_DROITE_SetLow();
return 0;
}

int Avancer(int vts)
{
    PWM_D1_LoadDutyValue(vts);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(vts);   
    LED_STOP_SetLow();
    LED_GAUCHE_SetHigh();
    LED_DROITE_SetHigh();
return 0;
}

int Stopper(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(0); 
    LED_STOP_SetHigh();
    LED_GAUCHE_SetLow();
    LED_DROITE_SetLow();
}

int Gauche(int vts)
{
    PWM_D1_LoadDutyValue(vts);
    PWM_D2_LoadDutyValue(0);
    PWM_G1_LoadDutyValue(vts);
    PWM_G2_LoadDutyValue(0);
    LED_STOP_SetLow();
    LED_GAUCHE_SetHigh();
    LED_DROITE_SetLow();
}

int Droite(int vts)
{
    PWM_D1_LoadDutyValue(0);
    PWM_D2_LoadDutyValue(vts);
    PWM_G1_LoadDutyValue(0);
    PWM_G2_LoadDutyValue(vts);
    
    LED_STOP_SetLow();
    LED_GAUCHE_SetLow();
    LED_DROITE_SetHigh();
}




int main(void)
{
    SYSTEM_Initialize(); 
    
    uint16_t val_pot;
    float pourcent;
    char consigne = 0 ;
    char memo ; 
    
    while(1)
    { 
        val_pot = ADC_ChannelSelectAndConvert(POT);
               
        printf("Veuillez saisir un caractere : \n ") ;
        consigne = EUSART_Read() ;
      
        
        if ( consigne == 'z' ||  memo == 'z' )
        {
          Avancer(val_pot);
          memo = 'z';
          printf("Avancer \n");
          __delay_ms(100);
        }
        
         if ( consigne == 'q' || memo == 'q')
        {
          Gauche(val_pot);
          memo = 'q';
          printf("Gauche \n");
          __delay_ms(100);
        }
        
         if ( consigne == 'd' || memo == 'd')
        {
          Droite(val_pot);
          memo = 'd';
          printf("Droite \n");
          __delay_ms(100);
        }
        
         if ( consigne == 's' ||  memo == 's')
        {
          Reculer(val_pot);
          memo = 's';
          printf("Reculer \n");
          __delay_ms(100);
        }
        
        if (consigne == 'p' || memo == 'p')
        {
          Stopper(val_pot); 
          memo = 'p';
          printf("Stopper \n");
        }
    }
   
        
        
       
        
        
   
        
        
        
        
    
}
Algorithme CALCUL_VITESSE(temperature_actuelle)

VAR
	vitesse_convoyeur r�el
Fin VAR

Debut
	Si temperature_actuelle > -15 alors
		vitesse_convoyeur = 0
	Fin Si
	
	Si temperature_actuelle < ou = -15 et temperature_actuelle > -18 alors
		vitesse_convoyeur = 0.5
	Fin Si
	
	Si temperature_actuelle < ou = -18 alors
		vitesse_convoyeur = 1
	Fin Si
	
	Retourner vitesse_convoyeur

Fin 
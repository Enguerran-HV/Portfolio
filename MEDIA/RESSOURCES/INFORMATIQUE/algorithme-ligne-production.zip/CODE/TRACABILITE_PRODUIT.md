Algorithme TRACABILITE_PRODUIT(fichier_suivie, numero_produit, t, T_actuelle, puissance, vitesse)

VAR
	Code_produit chaine de caractère
Fin VAR



Debut
	Code_produit = 'PROD' + de entier a chaine de caractère(numero_produit)
	
	Ecrire dans fichier_suivie Code_produit
	Ecrire dans fichier_suivie t
	Ecrire dans fichier_suivie T_actuelle
	Ecrire dans fichier_suivie puissance
	Ecrire dans fichier_suivie vitesse
	Retour a la ligne 
Fin


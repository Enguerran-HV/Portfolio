Algorithme AFFICHAGE_PROCEDE(t, T_actuelle, puissance, vitesse)

VAR
Fin VAR

Debut

	Si t == 0 alors
		Ecrire 'Temps'
		Ecrire 'Temperature'
		Ecrire 'Puissance'
		Ecrire 'Vitesse'
		Retour � la ligne
	Fin Si
	
	Ecrire t
	Ecrire T_actuelle
	Ecrire puissance
	Ecrire vitesse
	Retour � la ligne
Fin
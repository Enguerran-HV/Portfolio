Algorithme AVANCER_CONVOYEUR(distance, vitesse)

VAR
	distance r�el
Fin VAR

Debut

	distance = distance + vitesse
	
	Retourner distance 
Fin


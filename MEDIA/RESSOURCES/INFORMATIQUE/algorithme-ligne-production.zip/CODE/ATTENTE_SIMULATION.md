Algorithme ATTENTE_SIMULATION(duree_attente)

VAR
Fin VAR

Debut
	//conversion de  seconde en micro seconde
	Attente de duree_attente en micro seconde
Fin
Algorithme CALCUL_TEMPERATURE_ACTUELLE(Temperature_suivante)

VAR
	 Temperature_actuelle r�el
	 Bruit 				r�el
Fin VAR

Debut
	// GENERATION DU BRUIT
	Bruit = al�atoire(-0.3 � +0.3)
	
	// CALCUL TEMPERATURE ACTUELLE
	Temperature_actuelle = Temperature_suivante + bruit
	
	retourner Temperature_actuelle
Fin 

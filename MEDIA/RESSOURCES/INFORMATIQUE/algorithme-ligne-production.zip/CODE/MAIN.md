Algorithme MAIN()

Var
	CONSTANTE 
		temps_max = 360
		nombre_valeur = 361
		T_ambiante = 20
		T_consigne = -20
		dist_produit = 2
	
	TABLEAU
		tab_temperature[nombre_valeur]
		tab_puissance[nombre_valeur]
		tab_vitesse_convoyeur[nombre_valeur]
		
	VARIABLE 
		t				entier 
		T_actuelle 		r�el 
		T_suivante 		r�el
		puissance 		r�el
		vitesse 		r�el
		distance		r�el
		numero_produit	entier
		produit_detecte	bool�en
		duree_attente 	r�el
		
	AUTRE
		fichier_suivie 	fichier 
		fichier_rapport fichier 
	
Fin Var

Debut

	T_actuelle = T_ambiante
	T_suivante = T_ambiante
	T_consigne = -20
	distance = 0
	numero_produit = 0
	t = 0
	puissance = 0

	duree_attente = SAISIE_DUREE_ATTENTE()
	OUVERTURE_FICHIERS(fichier_suivi, fichier_rapport)

	tant que t < ou =  temps_max faire
		T_actuelle = CALCUL_TEMPERATURE_ACTUELLE(T_suivante)
		puissance = CALCUL_PUISSANCE(T_actuelle, T_consigne)
		T_suivante = CALCUL_TEMPERATURE_SUIVANTE(T_actuelle, puissance)
		vitesse = CALCUL_VITESSE(T_suivante)
		ENREGISTREMENT_TABLEAUX(t, T_actuelle, puissance, vitesse, 
				tab_temperature, tab_puissance, tab_vitesse_convoyeur)
		AFFICHAGE_PROCEDE(t, T_actuelle, puissance, vitesse)
		distance = AVANCER_CONVOYEUR(distance, vitesse)
		produit_detecte = DETECTION_PRODUIT(distance)

		Si produit_detecte alors
			numero_produit = numero_produit + 1
			TRACABILITE_PRODUIT(fichier_suivie, numero_produit, t, T_actuelle, puissance, vitesse)
		Fin Si

		ATTENTE_SIMULATION(duree_attente)
		t = t + 1
	Fin tant que

	BILAN_FINAL(tab_temperature, tab_puissance, tab_vitesse_convoyeur, numero_produit, fichier_rapport)
	FERMETURE_FICHIERS(fichier_suivie, fichier_rapport)

Fin
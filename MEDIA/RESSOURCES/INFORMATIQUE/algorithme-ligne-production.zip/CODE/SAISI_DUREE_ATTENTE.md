Algorithme SAISI_DUREE_ATTENTE()

VAR
	duree_attente entier
	
Fin VAR

Debut
	Ecrire "Entrez le temps d'attente simuler du processus"
	Lire entr�e utilisateur 
	duree_attente = Entr�e utilisateur
	
	retourner duree_attente
Fin

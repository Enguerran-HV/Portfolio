Algorithme OUVERTURE_FICHIER()

VAR
Fin VAR

Debut
	Ouvrir fichier_suivie en écriture
	Ouvrir fichier_rapport en écriture 
	
	Ecrire dans fichier_rapport : "Temps (min);Temperature (°C);Puissance (%);Vitesse (m/min)", retour a la ligne
	Ecrire dans fichier_suivie : "CodeProduit;Temps_min;Temps (min);Temperature (°C);Puissance (%);Vitesse (m/min)", Retour a la ligne
Fin
Algorithme CALCUL_PUISSANCE(Temperature_actuelle, consigne)

VAR
	 Puissance r�el
Fin VAR

Debut
	// CALCUL PUISSANCE
	Puissance = 25 * (Temperature_actuele - consigne)
	
	//S�CURIT� LIMITE DE PLAGE
	Si Puissance > 100 alors
		Puissance = 100
	Fin Si
	Si Puissance < 0 alors
		Puissance = 0
	Fin Si
	
	retourner Puissance
Fin 

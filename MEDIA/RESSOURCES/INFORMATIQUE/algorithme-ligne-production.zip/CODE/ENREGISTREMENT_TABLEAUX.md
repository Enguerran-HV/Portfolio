Algorithme ENREGISTREMENT_TABLEAUX(t, T_actuelle, puissance, vitesse, 
				tab_temp, tab_puis, tab_vit_conv)

VAR
	
Fin VAR

Debut
	tab_temp[t] = T_actuelle
	tab_puis[t] = puissance
	tab_vit_conv[t] = vitesse
Fin 
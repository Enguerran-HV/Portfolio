Algorithme CALCUL_TEMPERATURE_SUIVANTE(Temperature_actuelle, Puissance)

VAR
	 Temperature_suivante r�el
Fin VAR

Debut
	// CALCUL TEMPERATURE SUIVANTE 
	Temperature_suivante = Temperature_actuelle + 0.05 * (20-Temperature_actuelle) - 0.012*Puissance
	
	retourner Temperature_suivante
Fin 

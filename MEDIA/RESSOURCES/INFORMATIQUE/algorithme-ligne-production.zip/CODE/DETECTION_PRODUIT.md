Algorithme DETECTION_PRODUIT(distance)

VAR
	produit_detecte bool�en 
Fin VAR

Debut

	Si distance modulo 2 = 0 Alors
		produit_detecte = VRAI
	Sinon 
		produit_detecte = FAUX
	Fin Si
	
	Retourner produit_detecte 
Fin

